

***********************NON-BOOT MODE***********************
eagle.flash.bin		0x00000
eagle.irom0text.bin	0x40000
blank.bin		0x3e000		
esp_init_data_default.bin  0x7c000

***********************************************************
